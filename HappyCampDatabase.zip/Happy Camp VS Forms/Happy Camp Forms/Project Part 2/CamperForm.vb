﻿Imports System.ComponentModel

Public Class CamperForm
    Private Sub CamperBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles CamperBindingNavigatorSaveItem.Click, CamperBindingNavigatorSaveItem.Click, CamperBindingNavigatorSaveItem.Click, CamperBindingNavigatorSaveItem.Click, CamperBindingNavigatorSaveItem.Click
        Try
            Me.Validate()
            Me.CamperBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.HappyCampDataSet)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub CamperForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HappyCampDataSet.Camper' table. You can move, or remove it, as needed.
        Me.CamperTableAdapter.Fill(Me.HappyCampDataSet.Camper)
    End Sub

    'These next 4 buttons check the age of the campers and filter it
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Age8to10.Click
        Try
            Me.CamperBindingSource.Filter = "CamperBirthday >= '7/1/2012' AND CamperBirthday <= '12/31/2013'"
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the Button")
        End Try
    End Sub

    Private Sub Born2007_Click(sender As Object, e As EventArgs) Handles Age12to15.Click
        Try
            Me.CamperBindingSource.Filter = "CamperBirthday >= '7/1/2007' AND CamperBirthday <= '7/1/2010'"
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the Button")
        End Try
    End Sub

    Private Sub Born2008_Click(sender As Object, e As EventArgs) Handles Age9to12.Click
        Try
            Me.CamperBindingSource.Filter = "CamperBirthday >= '7/1/2010' AND CamperBirthday <= '7/1/2013'"
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the Button")
        End Try
    End Sub

    Private Sub BDayAll_Click(sender As Object, e As EventArgs) Handles BDayAll.Click
        Try
            Me.CamperBindingSource.Filter = "CamperBirthday >= '1/1/2006' AND CamperBirthday <= '12/31/2014'"
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the Button")
        End Try
    End Sub

    'This creates a new camper ID when you press the add button
    Dim IsAdding As Boolean = False
    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True
    End Sub
    Private Sub CamperBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles CamperBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(CamperID) AS MaxID FROM Camper"
                cmd.CommandType = CommandType.Text
                cmd.Connection = Me.CamperTableAdapter.Connection
                Dim i As Integer
                If cmd.Connection.State = ConnectionState.Closed Then
                    cmd.Connection.Open()
                    i = cmd.ExecuteScalar() + 1
                    cmd.Connection.Close()
                End If
                Me.CamperIDTextBox.Text = i.ToString
                IsAdding = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If
    End Sub

    'This is a function that checks the difference in age
    Private Function BdayCheck(ByVal CamperBirthday As Date) As String
        Try
            Dim campstart As Date
            campstart = "6 / 10 / 2021"
            Dim years As Long = DateDiff(DateInterval.Year, CamperBirthday, campstart)
            MessageBox.Show("Camper Age: " & years.ToString)
        Catch ex As Exception
            MessageBox.Show("Age not Working: " & ex.Message)
        End Try
        Return CamperBirthday
    End Function

    Private Sub Bday_Click(sender As Object, e As EventArgs) Handles Bday.Click
        Try
            BdayCheck(CamperBirthday.Text)
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the Button")
        End Try
    End Sub

    'this closes the form
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


    Private Sub FillBy2ToolStripButton_Click(sender As Object, e As EventArgs) Handles FillBy2ToolStripButton.Click
        Try
            Me.CamperTableAdapter.FillBy2(Me.HappyCampDataSet.Camper, CType(CamperIDToolStripTextBox.Text, Integer))
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub CamperIDToolStripTextBox_Validating(sender As Object, e As CancelEventArgs) Handles CamperIDToolStripTextBox.Validating
        Dim cmd As New Data.SqlClient.SqlCommand
        cmd.CommandText = "SELECT Max(CamperID) AS MaxID FROM Camper"
        cmd.CommandType = CommandType.Text
        cmd.Connection = Me.CamperTableAdapter.Connection
        cmd.Connection.Open()
        Dim i As Integer
        i = cmd.ExecuteScalar()
        cmd.Connection.Close()
        If String.IsNullOrEmpty(CamperIDToolStripTextBox.Text) Then
            CamperIDToolStripTextBox.Text = ""
        ElseIf (CType(CamperIDToolStripTextBox.Text, Integer) > i) Or (CType(CamperIDToolStripTextBox.Text, Integer) <= 0) Then
            MsgBox("No Camper Matched the Camper ID")
        End If
    End Sub

    Private Sub btnFill_Click(sender As Object, e As EventArgs) Handles btnFill.Click
        Me.CamperTableAdapter.Fill(Me.HappyCampDataSet.Camper)
    End Sub
End Class

