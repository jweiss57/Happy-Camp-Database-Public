﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Startup
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnStaff = New System.Windows.Forms.Button()
        Me.btnCamper = New System.Windows.Forms.Button()
        Me.btnParent = New System.Windows.Forms.Button()
        Me.btnSearch = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Project_Part_2.My.Resources.Resources.Happy_Camp
        Me.PictureBox1.Location = New System.Drawing.Point(14, 69)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(166, 89)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 43
        Me.PictureBox1.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(812, 81)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(129, 31)
        Me.btnExit.TabIndex = 42
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(212, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(546, 40)
        Me.Label1.TabIndex = 41
        Me.Label1.Text = "Happy Camp Information System"
        '
        'btnStaff
        '
        Me.btnStaff.Location = New System.Drawing.Point(572, 200)
        Me.btnStaff.Name = "btnStaff"
        Me.btnStaff.Size = New System.Drawing.Size(163, 60)
        Me.btnStaff.TabIndex = 44
        Me.btnStaff.Text = "Staff Form"
        Me.btnStaff.UseVisualStyleBackColor = True
        '
        'btnCamper
        '
        Me.btnCamper.Location = New System.Drawing.Point(193, 306)
        Me.btnCamper.Name = "btnCamper"
        Me.btnCamper.Size = New System.Drawing.Size(163, 60)
        Me.btnCamper.TabIndex = 45
        Me.btnCamper.Text = "Camper Form"
        Me.btnCamper.UseVisualStyleBackColor = True
        '
        'btnParent
        '
        Me.btnParent.Location = New System.Drawing.Point(572, 306)
        Me.btnParent.Name = "btnParent"
        Me.btnParent.Size = New System.Drawing.Size(163, 60)
        Me.btnParent.TabIndex = 46
        Me.btnParent.Text = "Parent Sub Form"
        Me.btnParent.UseVisualStyleBackColor = True
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(202, 200)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(163, 60)
        Me.btnSearch.TabIndex = 47
        Me.btnSearch.Text = "Search Form"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'Startup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(953, 475)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.btnParent)
        Me.Controls.Add(Me.btnCamper)
        Me.Controls.Add(Me.btnStaff)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Startup"
        Me.Text = "Startup"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnStaff As Button
    Friend WithEvents btnCamper As Button
    Friend WithEvents btnParent As Button
    Friend WithEvents btnSearch As Button
End Class
