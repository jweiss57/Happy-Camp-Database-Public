﻿Public Class ParentSubForm
    Private Sub ParentBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles ParentBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ParentBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.HappyCampDataSet)
        Me.RegistrationBindingSource.EndEdit()
        Me.RegistrationTableAdapter.Update(Me.HappyCampDataSet)
    End Sub

    Private Sub ParentSubForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HappyCampDataSet1.Camper' table. You can move, or remove it, as needed.
        Me.CamperTableAdapter.Fill(Me.HappyCampDataSet1.Camper)
        'TODO: This line of code loads data into the 'HappyCampDataSet.Registration' table. You can move, or remove it, as needed.
        Me.RegistrationTableAdapter.Fill(Me.HappyCampDataSet.Registration)
        'TODO: This line of code loads data into the 'HappyCampDataSet.Parent' table. You can move, or remove it, as needed.
        Me.ParentTableAdapter.Fill(Me.HappyCampDataSet.Parent)
    End Sub

    'This solves errors when they close
    Private Sub ParentSubForm_Closing(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        RegistrationBindingSource.Dispose()
        RegistrationDataGridView.Dispose()
    End Sub

    'This helps add a new camper ID when pressing the add button
    Dim IsAdding As Boolean = False
    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True

    End Sub

    Private Sub ParentBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles ParentBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(ParentID) AS MaxID FROM Parent"
                cmd.CommandType = CommandType.Text
                cmd.Connection = Me.ParentTableAdapter.Connection
                Dim i As Integer
                If cmd.Connection.State = ConnectionState.Closed Then
                    cmd.Connection.Open()
                    i = cmd.ExecuteScalar() + 1
                    cmd.Connection.Close()
                End If
                Me.ParentIDTextBox.Text = i.ToString
                IsAdding = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    'This helps you filter by last name
    Private Sub FillBy1ToolStripButton_Click(sender As Object, e As EventArgs) Handles FillBy1ToolStripButton.Click
        Try
            Me.ParentTableAdapter.FillBy1(Me.HappyCampDataSet.Parent, ParentLastNameToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
        If Me.ParentLastNameComboBox.Text = "" Then
            MsgBox("No Parent Matched the Last Name")
        End If
    End Sub

    'This is a subprocedure that brings back the a count and the salary amount
    Private Sub RegistrationDataGridView_RowPostPaint(sender As Object, e As DataGridViewRowPostPaintEventArgs) Handles RegistrationDataGridView.RowPostPaint
        Try
            Dim count As Integer
            count = Me.RegistrationDataGridView.Rows.Count - 1
            CountCamper.Text = count.ToString

            Dim Sal As Integer
            If (count > 0) Then
                Sal = 1900 * count
            Else Sal = 0
            End If
            AmountOwed.Text = Sal.ToString("$ #,##0")
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the SUB")
        End Try
    End Sub

    'This creates the row index
    Private Sub RegistrationDataGridView_RowPrePaint(sender As Object, e As DataGridViewRowPrePaintEventArgs) Handles RegistrationDataGridView.RowPrePaint
        Try
            If e.RowIndex >= 0 Then
                Me.RegistrationDataGridView.Rows(e.RowIndex).Cells(0).Value = e.RowIndex + 1
            End If
        Catch ex As System.Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    'This closes the form
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnFill_Click(sender As Object, e As EventArgs) Handles btnFill.Click
        Try
            Me.ParentTableAdapter.Fill(Me.HappyCampDataSet.Parent)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Dim NewDate As DateTime = DateTime.Now
    Private Sub RegistrationDataGridView_Click(sender As Object, e As EventArgs) Handles RegistrationDataGridView.Click
        RegistrationDataGridView.Rows(RegistrationDataGridView.Rows.Count - 1).Cells("RegistrationDateTime").Value = NewDate
    End Sub
End Class