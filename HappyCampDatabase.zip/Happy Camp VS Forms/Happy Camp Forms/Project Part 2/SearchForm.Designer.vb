﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SearchForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.BegDate = New System.Windows.Forms.DateTimePicker()
        Me.EndDate = New System.Windows.Forms.DateTimePicker()
        Me.CboUnitName = New System.Windows.Forms.ComboBox()
        Me.UnitBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HappyCampDataSet = New Project_Part_2.HappyCampDataSet()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.UnitTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.UnitTableAdapter()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.CamperInfoViewBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CamperInfoViewTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.CamperInfoViewTableAdapter()
        Me.TableAdapterManager = New Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager()
        Me.CamperInfoViewDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegistrationDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TxtCount = New System.Windows.Forms.Label()
        Me.CamperClass = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.CamperAmount = New System.Windows.Forms.Label()
        Me.CountCheck = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.GrossIncome = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.UnitBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CamperInfoViewBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CamperInfoViewDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BegDate
        '
        Me.BegDate.Location = New System.Drawing.Point(192, 226)
        Me.BegDate.Name = "BegDate"
        Me.BegDate.Size = New System.Drawing.Size(297, 26)
        Me.BegDate.TabIndex = 0
        Me.BegDate.Value = New Date(2020, 11, 13, 0, 0, 0, 0)
        '
        'EndDate
        '
        Me.EndDate.Location = New System.Drawing.Point(192, 276)
        Me.EndDate.Name = "EndDate"
        Me.EndDate.Size = New System.Drawing.Size(297, 26)
        Me.EndDate.TabIndex = 1
        Me.EndDate.Value = New Date(2021, 4, 19, 0, 0, 0, 0)
        '
        'CboUnitName
        '
        Me.CboUnitName.DataSource = Me.UnitBindingSource
        Me.CboUnitName.DisplayMember = "UnitName"
        Me.CboUnitName.FormattingEnabled = True
        Me.CboUnitName.Location = New System.Drawing.Point(841, 224)
        Me.CboUnitName.Name = "CboUnitName"
        Me.CboUnitName.Size = New System.Drawing.Size(167, 28)
        Me.CboUnitName.TabIndex = 2
        Me.CboUnitName.ValueMember = "UnitName"
        '
        'UnitBindingSource
        '
        Me.UnitBindingSource.DataMember = "Unit"
        Me.UnitBindingSource.DataSource = Me.HappyCampDataSet
        '
        'HappyCampDataSet
        '
        Me.HappyCampDataSet.DataSetName = "HappyCampDataSet"
        Me.HappyCampDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'btnSearch
        '
        Me.btnSearch.Location = New System.Drawing.Point(837, 276)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(171, 41)
        Me.btnSearch.TabIndex = 3
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = True
        '
        'UnitTableAdapter
        '
        Me.UnitTableAdapter.ClearBeforeFill = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(13, 226)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 20)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Start Registration Date"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(13, 276)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(167, 20)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "End Registration Date"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(727, 224)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 20)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Unit Name"
        '
        'CamperInfoViewBindingSource
        '
        Me.CamperInfoViewBindingSource.DataMember = "CamperInfoView"
        Me.CamperInfoViewBindingSource.DataSource = Me.HappyCampDataSet
        '
        'CamperInfoViewTableAdapter
        '
        Me.CamperInfoViewTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CamperTableAdapter = Nothing
        Me.TableAdapterManager.EnrollTableAdapter = Nothing
        Me.TableAdapterManager.ParentTableAdapter = Nothing
        Me.TableAdapterManager.RegistrationTableAdapter = Nothing
        Me.TableAdapterManager.SpecialtyTableAdapter = Nothing
        Me.TableAdapterManager.SummerStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitTableAdapter = Me.UnitTableAdapter
        Me.TableAdapterManager.UpdateOrder = Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CamperInfoViewDataGridView
        '
        Me.CamperInfoViewDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.CamperInfoViewDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.CamperInfoViewDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.CamperInfoViewDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.RegistrationDate, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8})
        Me.CamperInfoViewDataGridView.DataSource = Me.CamperInfoViewBindingSource
        Me.CamperInfoViewDataGridView.Location = New System.Drawing.Point(47, 387)
        Me.CamperInfoViewDataGridView.Name = "CamperInfoViewDataGridView"
        Me.CamperInfoViewDataGridView.RowHeadersWidth = 62
        Me.CamperInfoViewDataGridView.RowTemplate.Height = 28
        Me.CamperInfoViewDataGridView.Size = New System.Drawing.Size(1224, 220)
        Me.CamperInfoViewDataGridView.TabIndex = 7
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "ParentID"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Parent ID"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 50
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "ParentFullName"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Parent Name"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Width = 120
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "ParentEmail"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Parent Email"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 150
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "CamperID"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Camper ID"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 50
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "CamperFullName"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Camper Name"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Width = 120
        '
        'RegistrationDate
        '
        Me.RegistrationDate.DataPropertyName = "RegistrationDateTime"
        Me.RegistrationDate.HeaderText = "Registration Time"
        Me.RegistrationDate.MinimumWidth = 8
        Me.RegistrationDate.Name = "RegistrationDate"
        Me.RegistrationDate.Width = 120
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "UnitName"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Unit Name"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 80
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "SpecialtyType"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Specialty Type"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 80
        '
        'TxtCount
        '
        Me.TxtCount.AutoSize = True
        Me.TxtCount.Location = New System.Drawing.Point(483, 331)
        Me.TxtCount.Name = "TxtCount"
        Me.TxtCount.Size = New System.Drawing.Size(0, 20)
        Me.TxtCount.TabIndex = 11
        '
        'CamperClass
        '
        Me.CamperClass.AutoSize = True
        Me.CamperClass.Location = New System.Drawing.Point(868, 331)
        Me.CamperClass.Name = "CamperClass"
        Me.CamperClass.Size = New System.Drawing.Size(0, 20)
        Me.CamperClass.TabIndex = 12
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(360, 331)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(300, 20)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Amount of Campers Needed to Run Unit:"
        '
        'CamperAmount
        '
        Me.CamperAmount.AutoSize = True
        Me.CamperAmount.Location = New System.Drawing.Point(666, 331)
        Me.CamperAmount.Name = "CamperAmount"
        Me.CamperAmount.Size = New System.Drawing.Size(0, 20)
        Me.CamperAmount.TabIndex = 14
        '
        'CountCheck
        '
        Me.CountCheck.AutoSize = True
        Me.CountCheck.Location = New System.Drawing.Point(833, 331)
        Me.CountCheck.Name = "CountCheck"
        Me.CountCheck.Size = New System.Drawing.Size(0, 20)
        Me.CountCheck.TabIndex = 15
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(30, 336)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(113, 20)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Gross Income:"
        '
        'GrossIncome
        '
        Me.GrossIncome.AutoSize = True
        Me.GrossIncome.Location = New System.Drawing.Point(138, 336)
        Me.GrossIncome.Name = "GrossIncome"
        Me.GrossIncome.Size = New System.Drawing.Size(0, 20)
        Me.GrossIncome.TabIndex = 17
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Project_Part_2.My.Resources.Resources.Happy_Camp
        Me.PictureBox1.Location = New System.Drawing.Point(131, 56)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(166, 89)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(960, 64)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(129, 31)
        Me.btnClose.TabIndex = 39
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(389, 55)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(479, 40)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "Camper Parent Search Form"
        '
        'SearchForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1271, 672)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.GrossIncome)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.CountCheck)
        Me.Controls.Add(Me.CamperAmount)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.CamperClass)
        Me.Controls.Add(Me.TxtCount)
        Me.Controls.Add(Me.CamperInfoViewDataGridView)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.CboUnitName)
        Me.Controls.Add(Me.EndDate)
        Me.Controls.Add(Me.BegDate)
        Me.Name = "SearchForm"
        Me.Text = "SearchForm"
        CType(Me.UnitBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CamperInfoViewBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CamperInfoViewDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents BegDate As DateTimePicker
    Friend WithEvents EndDate As DateTimePicker
    Friend WithEvents CboUnitName As ComboBox
    Friend WithEvents btnSearch As Button
    Friend WithEvents HappyCampDataSet As HappyCampDataSet
    Friend WithEvents UnitBindingSource As BindingSource
    Friend WithEvents UnitTableAdapter As HappyCampDataSetTableAdapters.UnitTableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents CamperInfoViewBindingSource As BindingSource
    Friend WithEvents CamperInfoViewTableAdapter As HappyCampDataSetTableAdapters.CamperInfoViewTableAdapter
    Friend WithEvents TableAdapterManager As HappyCampDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CamperInfoViewDataGridView As DataGridView
    Friend WithEvents TxtCount As Label
    Friend WithEvents CamperClass As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents CamperAmount As Label
    Friend WithEvents CountCheck As Label
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents RegistrationDate As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents Label5 As Label
    Friend WithEvents GrossIncome As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnClose As Button
    Friend WithEvents Label6 As Label
End Class
