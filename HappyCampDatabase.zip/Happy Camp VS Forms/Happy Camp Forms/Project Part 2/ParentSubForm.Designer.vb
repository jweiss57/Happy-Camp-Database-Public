﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ParentSubForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ParentIDLabel As System.Windows.Forms.Label
        Dim ParentFirstNameLabel As System.Windows.Forms.Label
        Dim ParentLastNameLabel As System.Windows.Forms.Label
        Dim ParentCityLabel As System.Windows.Forms.Label
        Dim ParentStateLabel As System.Windows.Forms.Label
        Dim ParentEmailLabel As System.Windows.Forms.Label
        Dim ParentAdressLabel As System.Windows.Forms.Label
        Dim ParentZipCodeLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ParentSubForm))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.HappyCampDataSet = New Project_Part_2.HappyCampDataSet()
        Me.ParentBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ParentTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.ParentTableAdapter()
        Me.TableAdapterManager = New Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager()
        Me.ParentBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ParentBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.ParentFirstNameComboBox = New System.Windows.Forms.ComboBox()
        Me.ParentLastNameComboBox = New System.Windows.Forms.ComboBox()
        Me.ParentCityTextBox = New System.Windows.Forms.TextBox()
        Me.ParentStateTextBox = New System.Windows.Forms.TextBox()
        Me.ParentEmailTextBox = New System.Windows.Forms.TextBox()
        Me.RegistrationBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.RegistrationTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.RegistrationTableAdapter()
        Me.CamperBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HappyCampDataSet1 = New Project_Part_2.HappyCampDataSet()
        Me.CamperTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.CamperTableAdapter()
        Me.FillBy1ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.ParentLastNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.ParentLastNameToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillBy1ToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.CountCamper = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.AmountOwed = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.RegistrationDataGridView = New System.Windows.Forms.DataGridView()
        Me.ParentIDTextBox = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnFill = New System.Windows.Forms.Button()
        Me.ParentAdressTextBox = New System.Windows.Forms.TextBox()
        Me.ParentZipCodeTextBox = New System.Windows.Forms.TextBox()
        Me.RowIndex = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RegistrationDateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewComboBoxColumn()
        ParentIDLabel = New System.Windows.Forms.Label()
        ParentFirstNameLabel = New System.Windows.Forms.Label()
        ParentLastNameLabel = New System.Windows.Forms.Label()
        ParentCityLabel = New System.Windows.Forms.Label()
        ParentStateLabel = New System.Windows.Forms.Label()
        ParentEmailLabel = New System.Windows.Forms.Label()
        ParentAdressLabel = New System.Windows.Forms.Label()
        ParentZipCodeLabel = New System.Windows.Forms.Label()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParentBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParentBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ParentBindingNavigator.SuspendLayout()
        CType(Me.RegistrationBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CamperBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HappyCampDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillBy1ToolStrip.SuspendLayout()
        CType(Me.RegistrationDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ParentIDLabel
        '
        ParentIDLabel.AutoSize = True
        ParentIDLabel.Location = New System.Drawing.Point(250, 173)
        ParentIDLabel.Name = "ParentIDLabel"
        ParentIDLabel.Size = New System.Drawing.Size(81, 20)
        ParentIDLabel.TabIndex = 1
        ParentIDLabel.Text = "Parent ID:"
        '
        'ParentFirstNameLabel
        '
        ParentFirstNameLabel.AutoSize = True
        ParentFirstNameLabel.Location = New System.Drawing.Point(250, 207)
        ParentFirstNameLabel.Name = "ParentFirstNameLabel"
        ParentFirstNameLabel.Size = New System.Drawing.Size(141, 20)
        ParentFirstNameLabel.TabIndex = 3
        ParentFirstNameLabel.Text = "Parent First Name:"
        '
        'ParentLastNameLabel
        '
        ParentLastNameLabel.AutoSize = True
        ParentLastNameLabel.Location = New System.Drawing.Point(250, 241)
        ParentLastNameLabel.Name = "ParentLastNameLabel"
        ParentLastNameLabel.Size = New System.Drawing.Size(141, 20)
        ParentLastNameLabel.TabIndex = 5
        ParentLastNameLabel.Text = "Parent Last Name:"
        '
        'ParentCityLabel
        '
        ParentCityLabel.AutoSize = True
        ParentCityLabel.Location = New System.Drawing.Point(661, 206)
        ParentCityLabel.Name = "ParentCityLabel"
        ParentCityLabel.Size = New System.Drawing.Size(90, 20)
        ParentCityLabel.TabIndex = 11
        ParentCityLabel.Text = "Parent City:"
        '
        'ParentStateLabel
        '
        ParentStateLabel.AutoSize = True
        ParentStateLabel.Location = New System.Drawing.Point(661, 238)
        ParentStateLabel.Name = "ParentStateLabel"
        ParentStateLabel.Size = New System.Drawing.Size(103, 20)
        ParentStateLabel.TabIndex = 13
        ParentStateLabel.Text = "Parent State:"
        '
        'ParentEmailLabel
        '
        ParentEmailLabel.AutoSize = True
        ParentEmailLabel.Location = New System.Drawing.Point(661, 272)
        ParentEmailLabel.Name = "ParentEmailLabel"
        ParentEmailLabel.Size = New System.Drawing.Size(103, 20)
        ParentEmailLabel.TabIndex = 15
        ParentEmailLabel.Text = "Parent Email:"
        '
        'ParentAdressLabel
        '
        ParentAdressLabel.AutoSize = True
        ParentAdressLabel.Location = New System.Drawing.Point(250, 275)
        ParentAdressLabel.Name = "ParentAdressLabel"
        ParentAdressLabel.Size = New System.Drawing.Size(114, 20)
        ParentAdressLabel.TabIndex = 41
        ParentAdressLabel.Text = "Parent Adress:"
        '
        'ParentZipCodeLabel
        '
        ParentZipCodeLabel.AutoSize = True
        ParentZipCodeLabel.Location = New System.Drawing.Point(661, 173)
        ParentZipCodeLabel.Name = "ParentZipCodeLabel"
        ParentZipCodeLabel.Size = New System.Drawing.Size(128, 20)
        ParentZipCodeLabel.TabIndex = 42
        ParentZipCodeLabel.Text = "Parent Zip Code:"
        '
        'HappyCampDataSet
        '
        Me.HappyCampDataSet.DataSetName = "HappyCampDataSet"
        Me.HappyCampDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ParentBindingSource
        '
        Me.ParentBindingSource.DataMember = "Parent"
        Me.ParentBindingSource.DataSource = Me.HappyCampDataSet
        '
        'ParentTableAdapter
        '
        Me.ParentTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CamperTableAdapter = Nothing
        Me.TableAdapterManager.EnrollTableAdapter = Nothing
        Me.TableAdapterManager.ParentTableAdapter = Me.ParentTableAdapter
        Me.TableAdapterManager.RegistrationTableAdapter = Nothing
        Me.TableAdapterManager.SpecialtyTableAdapter = Nothing
        Me.TableAdapterManager.SummerStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'ParentBindingNavigator
        '
        Me.ParentBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ParentBindingNavigator.BindingSource = Me.ParentBindingSource
        Me.ParentBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ParentBindingNavigator.DeleteItem = Nothing
        Me.ParentBindingNavigator.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ParentBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.ParentBindingNavigatorSaveItem})
        Me.ParentBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ParentBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ParentBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ParentBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ParentBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ParentBindingNavigator.Name = "ParentBindingNavigator"
        Me.ParentBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ParentBindingNavigator.Size = New System.Drawing.Size(1283, 33)
        Me.ParentBindingNavigator.TabIndex = 0
        Me.ParentBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(54, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 31)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'ParentBindingNavigatorSaveItem
        '
        Me.ParentBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ParentBindingNavigatorSaveItem.Image = CType(resources.GetObject("ParentBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ParentBindingNavigatorSaveItem.Name = "ParentBindingNavigatorSaveItem"
        Me.ParentBindingNavigatorSaveItem.Size = New System.Drawing.Size(34, 28)
        Me.ParentBindingNavigatorSaveItem.Text = "Save Data"
        '
        'ParentFirstNameComboBox
        '
        Me.ParentFirstNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentFirstName", True))
        Me.ParentFirstNameComboBox.DataSource = Me.ParentBindingSource
        Me.ParentFirstNameComboBox.DisplayMember = "ParentFirstName"
        Me.ParentFirstNameComboBox.FormattingEnabled = True
        Me.ParentFirstNameComboBox.Location = New System.Drawing.Point(397, 204)
        Me.ParentFirstNameComboBox.Name = "ParentFirstNameComboBox"
        Me.ParentFirstNameComboBox.Size = New System.Drawing.Size(121, 28)
        Me.ParentFirstNameComboBox.TabIndex = 4
        Me.ParentFirstNameComboBox.ValueMember = "ParentFirstName"
        '
        'ParentLastNameComboBox
        '
        Me.ParentLastNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentLastName", True))
        Me.ParentLastNameComboBox.DataSource = Me.ParentBindingSource
        Me.ParentLastNameComboBox.DisplayMember = "ParentLastName"
        Me.ParentLastNameComboBox.FormattingEnabled = True
        Me.ParentLastNameComboBox.Location = New System.Drawing.Point(397, 238)
        Me.ParentLastNameComboBox.Name = "ParentLastNameComboBox"
        Me.ParentLastNameComboBox.Size = New System.Drawing.Size(121, 28)
        Me.ParentLastNameComboBox.TabIndex = 6
        Me.ParentLastNameComboBox.ValueMember = "ParentLastName"
        '
        'ParentCityTextBox
        '
        Me.ParentCityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentCity", True))
        Me.ParentCityTextBox.Location = New System.Drawing.Point(808, 203)
        Me.ParentCityTextBox.Name = "ParentCityTextBox"
        Me.ParentCityTextBox.Size = New System.Drawing.Size(121, 26)
        Me.ParentCityTextBox.TabIndex = 12
        '
        'ParentStateTextBox
        '
        Me.ParentStateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentState", True))
        Me.ParentStateTextBox.Location = New System.Drawing.Point(808, 235)
        Me.ParentStateTextBox.Name = "ParentStateTextBox"
        Me.ParentStateTextBox.Size = New System.Drawing.Size(121, 26)
        Me.ParentStateTextBox.TabIndex = 14
        '
        'ParentEmailTextBox
        '
        Me.ParentEmailTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentEmail", True))
        Me.ParentEmailTextBox.Location = New System.Drawing.Point(808, 269)
        Me.ParentEmailTextBox.Name = "ParentEmailTextBox"
        Me.ParentEmailTextBox.Size = New System.Drawing.Size(221, 26)
        Me.ParentEmailTextBox.TabIndex = 16
        '
        'RegistrationBindingSource
        '
        Me.RegistrationBindingSource.DataMember = "fk_registration_parent"
        Me.RegistrationBindingSource.DataSource = Me.ParentBindingSource
        '
        'RegistrationTableAdapter
        '
        Me.RegistrationTableAdapter.ClearBeforeFill = True
        '
        'CamperBindingSource
        '
        Me.CamperBindingSource.DataMember = "Camper"
        Me.CamperBindingSource.DataSource = Me.HappyCampDataSet1
        '
        'HappyCampDataSet1
        '
        Me.HappyCampDataSet1.DataSetName = "HappyCampDataSet"
        Me.HappyCampDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CamperTableAdapter
        '
        Me.CamperTableAdapter.ClearBeforeFill = True
        '
        'FillBy1ToolStrip
        '
        Me.FillBy1ToolStrip.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.FillBy1ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ParentLastNameToolStripLabel, Me.ParentLastNameToolStripTextBox, Me.FillBy1ToolStripButton})
        Me.FillBy1ToolStrip.Location = New System.Drawing.Point(0, 33)
        Me.FillBy1ToolStrip.Name = "FillBy1ToolStrip"
        Me.FillBy1ToolStrip.Size = New System.Drawing.Size(1283, 34)
        Me.FillBy1ToolStrip.TabIndex = 18
        Me.FillBy1ToolStrip.Text = "FillBy1ToolStrip"
        '
        'ParentLastNameToolStripLabel
        '
        Me.ParentLastNameToolStripLabel.Name = "ParentLastNameToolStripLabel"
        Me.ParentLastNameToolStripLabel.Size = New System.Drawing.Size(143, 29)
        Me.ParentLastNameToolStripLabel.Text = "ParentLastName:"
        '
        'ParentLastNameToolStripTextBox
        '
        Me.ParentLastNameToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.ParentLastNameToolStripTextBox.Name = "ParentLastNameToolStripTextBox"
        Me.ParentLastNameToolStripTextBox.Size = New System.Drawing.Size(100, 34)
        '
        'FillBy1ToolStripButton
        '
        Me.FillBy1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillBy1ToolStripButton.Name = "FillBy1ToolStripButton"
        Me.FillBy1ToolStripButton.Size = New System.Drawing.Size(68, 29)
        Me.FillBy1ToolStripButton.Text = "Search"
        '
        'CountCamper
        '
        Me.CountCamper.AutoSize = True
        Me.CountCamper.Location = New System.Drawing.Point(906, 314)
        Me.CountCamper.Name = "CountCamper"
        Me.CountCamper.Size = New System.Drawing.Size(57, 20)
        Me.CountCamper.TabIndex = 19
        Me.CountCamper.Text = "Label1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(250, 314)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(178, 20)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "Amount Owed to Camp:"
        '
        'AmountOwed
        '
        Me.AmountOwed.AutoSize = True
        Me.AmountOwed.Location = New System.Drawing.Point(434, 314)
        Me.AmountOwed.Name = "AmountOwed"
        Me.AmountOwed.Size = New System.Drawing.Size(57, 20)
        Me.AmountOwed.TabIndex = 21
        Me.AmountOwed.Text = "Label1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(661, 314)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(237, 20)
        Me.Label2.TabIndex = 22
        Me.Label2.Text = "Amount of Campers Registered:"
        '
        'RegistrationDataGridView
        '
        Me.RegistrationDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.RegistrationDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.RegistrationDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.RegistrationDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RowIndex, Me.RegistrationDateTime, Me.DataGridViewTextBoxColumn3})
        Me.RegistrationDataGridView.DataSource = Me.RegistrationBindingSource
        Me.RegistrationDataGridView.Location = New System.Drawing.Point(262, 370)
        Me.RegistrationDataGridView.Name = "RegistrationDataGridView"
        Me.RegistrationDataGridView.RowHeadersWidth = 62
        Me.RegistrationDataGridView.RowTemplate.Height = 28
        Me.RegistrationDataGridView.Size = New System.Drawing.Size(812, 220)
        Me.RegistrationDataGridView.TabIndex = 22
        '
        'ParentIDTextBox
        '
        Me.ParentIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentID", True))
        Me.ParentIDTextBox.Location = New System.Drawing.Point(397, 167)
        Me.ParentIDTextBox.Name = "ParentIDTextBox"
        Me.ParentIDTextBox.Size = New System.Drawing.Size(121, 26)
        Me.ParentIDTextBox.TabIndex = 23
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Project_Part_2.My.Resources.Resources.Happy_Camp
        Me.PictureBox1.Location = New System.Drawing.Point(69, 94)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(166, 89)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(970, 94)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(129, 31)
        Me.btnClose.TabIndex = 39
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(508, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(281, 40)
        Me.Label3.TabIndex = 38
        Me.Label3.Text = "ParentSub Form"
        '
        'btnFill
        '
        Me.btnFill.BackColor = System.Drawing.SystemColors.Window
        Me.btnFill.Location = New System.Drawing.Point(262, 94)
        Me.btnFill.Name = "btnFill"
        Me.btnFill.Size = New System.Drawing.Size(111, 31)
        Me.btnFill.TabIndex = 41
        Me.btnFill.Text = "Reset"
        Me.btnFill.UseVisualStyleBackColor = False
        '
        'ParentAdressTextBox
        '
        Me.ParentAdressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentAdress", True))
        Me.ParentAdressTextBox.Location = New System.Drawing.Point(397, 272)
        Me.ParentAdressTextBox.Name = "ParentAdressTextBox"
        Me.ParentAdressTextBox.Size = New System.Drawing.Size(121, 26)
        Me.ParentAdressTextBox.TabIndex = 42
        '
        'ParentZipCodeTextBox
        '
        Me.ParentZipCodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ParentBindingSource, "ParentZipCode", True))
        Me.ParentZipCodeTextBox.Location = New System.Drawing.Point(808, 170)
        Me.ParentZipCodeTextBox.Name = "ParentZipCodeTextBox"
        Me.ParentZipCodeTextBox.Size = New System.Drawing.Size(121, 26)
        Me.ParentZipCodeTextBox.TabIndex = 43
        '
        'RowIndex
        '
        Me.RowIndex.HeaderText = "Row Index"
        Me.RowIndex.MinimumWidth = 8
        Me.RowIndex.Name = "RowIndex"
        Me.RowIndex.Width = 150
        '
        'RegistrationDateTime
        '
        Me.RegistrationDateTime.DataPropertyName = "RegistrationDateTime"
        Me.RegistrationDateTime.HeaderText = "Registration Date"
        Me.RegistrationDateTime.MinimumWidth = 8
        Me.RegistrationDateTime.Name = "RegistrationDateTime"
        Me.RegistrationDateTime.Width = 150
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "CamperID"
        Me.DataGridViewTextBoxColumn3.DataSource = Me.CamperBindingSource
        Me.DataGridViewTextBoxColumn3.DisplayMember = "Camper Full Name"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Camper Name"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.DataGridViewTextBoxColumn3.ValueMember = "CamperID"
        Me.DataGridViewTextBoxColumn3.Width = 150
        '
        'ParentSubForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1283, 610)
        Me.Controls.Add(ParentZipCodeLabel)
        Me.Controls.Add(Me.ParentZipCodeTextBox)
        Me.Controls.Add(ParentAdressLabel)
        Me.Controls.Add(Me.ParentAdressTextBox)
        Me.Controls.Add(Me.btnFill)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ParentIDTextBox)
        Me.Controls.Add(Me.RegistrationDataGridView)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.AmountOwed)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.CountCamper)
        Me.Controls.Add(Me.FillBy1ToolStrip)
        Me.Controls.Add(ParentIDLabel)
        Me.Controls.Add(ParentFirstNameLabel)
        Me.Controls.Add(Me.ParentFirstNameComboBox)
        Me.Controls.Add(ParentLastNameLabel)
        Me.Controls.Add(Me.ParentLastNameComboBox)
        Me.Controls.Add(ParentCityLabel)
        Me.Controls.Add(Me.ParentCityTextBox)
        Me.Controls.Add(ParentStateLabel)
        Me.Controls.Add(Me.ParentStateTextBox)
        Me.Controls.Add(ParentEmailLabel)
        Me.Controls.Add(Me.ParentEmailTextBox)
        Me.Controls.Add(Me.ParentBindingNavigator)
        Me.Name = "ParentSubForm"
        Me.Text = "ParentSubForm"
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParentBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParentBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ParentBindingNavigator.ResumeLayout(False)
        Me.ParentBindingNavigator.PerformLayout()
        CType(Me.RegistrationBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CamperBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HappyCampDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillBy1ToolStrip.ResumeLayout(False)
        Me.FillBy1ToolStrip.PerformLayout()
        CType(Me.RegistrationDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents HappyCampDataSet As HappyCampDataSet
    Friend WithEvents ParentBindingSource As BindingSource
    Friend WithEvents ParentTableAdapter As HappyCampDataSetTableAdapters.ParentTableAdapter
    Friend WithEvents TableAdapterManager As HappyCampDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ParentBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents ParentBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents ParentFirstNameComboBox As ComboBox
    Friend WithEvents ParentLastNameComboBox As ComboBox
    Friend WithEvents ParentCityTextBox As TextBox
    Friend WithEvents ParentStateTextBox As TextBox
    Friend WithEvents ParentEmailTextBox As TextBox
    Friend WithEvents RegistrationBindingSource As BindingSource
    Friend WithEvents RegistrationTableAdapter As HappyCampDataSetTableAdapters.RegistrationTableAdapter
    Friend WithEvents HappyCampDataSet1 As HappyCampDataSet
    Friend WithEvents CamperBindingSource As BindingSource
    Friend WithEvents CamperTableAdapter As HappyCampDataSetTableAdapters.CamperTableAdapter
    Friend WithEvents FillBy1ToolStrip As ToolStrip
    Friend WithEvents ParentLastNameToolStripLabel As ToolStripLabel
    Friend WithEvents ParentLastNameToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillBy1ToolStripButton As ToolStripButton
    Friend WithEvents CountCamper As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents AmountOwed As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents RegistrationDataGridView As DataGridView
    Friend WithEvents ParentIDTextBox As TextBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnClose As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents btnFill As Button
    Friend WithEvents ParentAdressTextBox As TextBox
    Friend WithEvents ParentZipCodeTextBox As TextBox
    Friend WithEvents RowIndex As DataGridViewTextBoxColumn
    Friend WithEvents RegistrationDateTime As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewComboBoxColumn
End Class
