﻿Public Class SearchForm
    Private Sub SearchForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HappyCampDataSet.CamperInfoView' table. You can move, or remove it, as needed.
        'Me.CamperInfoViewTableAdapter.Fill(Me.HappyCampDataSet.CamperInfoView)
        'TODO: This line of code loads data into the 'HappyCampDataSet.Unit' table. You can move, or remove it, as needed.
        Me.UnitTableAdapter.Fill(Me.HappyCampDataSet.Unit)
    End Sub

    'This activates the search button 
    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        Try
            Me.CamperInfoViewTableAdapter.FillBy(
            Me.HappyCampDataSet.CamperInfoView,
            Me.CboUnitName.SelectedValue,
            Me.BegDate.Value,
            Me.EndDate.Value)
            CountMatches()
        Catch ex As Exception
            MsgBox(ex.Message, , "Error in the Query")
        End Try
        Dim n As Integer
        n = Me.CamperInfoViewDataGridView.Rows.Count - 1
        If n = 0 Then
            MsgBox("No Campers found!")
        End If
    End Sub

    'This is my sub procedure which calculates the count of campers, creates a gross income and checks the count to 
    'see if it is a good amount of campers
    Private Sub CountMatches()
        Try
            Dim count As Integer
            count = Me.CamperInfoViewDataGridView.Rows.Count - 1
            CamperAmount.Text = CType(count, String) + " Out of 60 Campers"
            Dim price As Integer
            If (count > 0) Then
                price = 1900 * count
            Else price = 0
            End If
            GrossIncome.Text = price.ToString("$ #,##0")
            If count <= 59 Then
                CountCheck.Text = "Need More Campers"
                CountCheck.ForeColor = Color.Red
            ElseIf count >= 60 Then
                CountCheck.Text = "Good Amount of Campers"
                CountCheck.ForeColor = Color.Green
            ElseIf count >= 100 Then
                CountCheck.Text = "Too many Campers"
                CountCheck.ForeColor = Color.Red
            End If
        Catch ex As System.Exception
            MsgBox(ex.Message, , "Error in the SUB")
        End Try
    End Sub

    'These next 2 subs validate the registration start date and end date
    Private Sub BegDate_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles BegDate.Validating
        If CType(BegDate.Text, DateTime) >= CType(EndDate.Text, DateTime) Then
            MsgBox("Registration Start Date must be before the End Date")
            e.Cancel = True
        End If
    End Sub

    Private Sub EndDate_Validating(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles EndDate.Validating
        If CType(EndDate.Text, DateTime) <= CType(BegDate.Text, DateTime) Then
            MsgBox("Registration Start Date must be before the End Date")
            e.Cancel = True
        End If
    End Sub

    'This sub helps the close button run
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub


End Class