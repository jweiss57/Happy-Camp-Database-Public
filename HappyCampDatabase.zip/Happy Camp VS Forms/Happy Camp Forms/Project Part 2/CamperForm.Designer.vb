﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CamperForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CamperIDLabel As System.Windows.Forms.Label
        Dim CamperAdressLabel As System.Windows.Forms.Label
        Dim CamperZipCodeLabel As System.Windows.Forms.Label
        Dim CamperCityLabel As System.Windows.Forms.Label
        Dim CamperStateLabel As System.Windows.Forms.Label
        Dim CamperBirthdayLabel As System.Windows.Forms.Label
        Dim CamperFirstNameLabel As System.Windows.Forms.Label
        Dim CamperLastNameLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CamperForm))
        Me.HappyCampDataSet = New Project_Part_2.HappyCampDataSet()
        Me.CamperBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.CamperTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.CamperTableAdapter()
        Me.TableAdapterManager = New Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager()
        Me.CamperBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.CamperBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.CamperAdressTextBox = New System.Windows.Forms.TextBox()
        Me.CamperZipCodeTextBox = New System.Windows.Forms.TextBox()
        Me.CamperCityTextBox = New System.Windows.Forms.TextBox()
        Me.CamperBirthday = New System.Windows.Forms.DateTimePicker()
        Me.Age8to10 = New System.Windows.Forms.Button()
        Me.Age12to15 = New System.Windows.Forms.Button()
        Me.Age9to12 = New System.Windows.Forms.Button()
        Me.BDayAll = New System.Windows.Forms.Button()
        Me.CamperStateTextBox = New System.Windows.Forms.TextBox()
        Me.CamperIDTextBox = New System.Windows.Forms.TextBox()
        Me.Bday = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnFill = New System.Windows.Forms.Button()
        Me.CamperFirstNameComboBox = New System.Windows.Forms.ComboBox()
        Me.CamperLastNameComboBox = New System.Windows.Forms.ComboBox()
        Me.FillBy2ToolStrip = New System.Windows.Forms.ToolStrip()
        Me.CamperIDToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.CamperIDToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillBy2ToolStripButton = New System.Windows.Forms.ToolStripButton()
        CamperIDLabel = New System.Windows.Forms.Label()
        CamperAdressLabel = New System.Windows.Forms.Label()
        CamperZipCodeLabel = New System.Windows.Forms.Label()
        CamperCityLabel = New System.Windows.Forms.Label()
        CamperStateLabel = New System.Windows.Forms.Label()
        CamperBirthdayLabel = New System.Windows.Forms.Label()
        CamperFirstNameLabel = New System.Windows.Forms.Label()
        CamperLastNameLabel = New System.Windows.Forms.Label()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CamperBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.CamperBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CamperBindingNavigator.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillBy2ToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'CamperIDLabel
        '
        CamperIDLabel.AutoSize = True
        CamperIDLabel.Location = New System.Drawing.Point(279, 206)
        CamperIDLabel.Name = "CamperIDLabel"
        CamperIDLabel.Size = New System.Drawing.Size(90, 20)
        CamperIDLabel.TabIndex = 1
        CamperIDLabel.Text = "Camper ID:"
        '
        'CamperAdressLabel
        '
        CamperAdressLabel.AutoSize = True
        CamperAdressLabel.Location = New System.Drawing.Point(653, 194)
        CamperAdressLabel.Name = "CamperAdressLabel"
        CamperAdressLabel.Size = New System.Drawing.Size(123, 20)
        CamperAdressLabel.TabIndex = 7
        CamperAdressLabel.Text = "Camper Adress:"
        '
        'CamperZipCodeLabel
        '
        CamperZipCodeLabel.AutoSize = True
        CamperZipCodeLabel.Location = New System.Drawing.Point(653, 229)
        CamperZipCodeLabel.Name = "CamperZipCodeLabel"
        CamperZipCodeLabel.Size = New System.Drawing.Size(137, 20)
        CamperZipCodeLabel.TabIndex = 9
        CamperZipCodeLabel.Text = "Camper Zip Code:"
        '
        'CamperCityLabel
        '
        CamperCityLabel.AutoSize = True
        CamperCityLabel.Location = New System.Drawing.Point(653, 261)
        CamperCityLabel.Name = "CamperCityLabel"
        CamperCityLabel.Size = New System.Drawing.Size(99, 20)
        CamperCityLabel.TabIndex = 11
        CamperCityLabel.Text = "Camper City:"
        '
        'CamperStateLabel
        '
        CamperStateLabel.AutoSize = True
        CamperStateLabel.Location = New System.Drawing.Point(653, 293)
        CamperStateLabel.Name = "CamperStateLabel"
        CamperStateLabel.Size = New System.Drawing.Size(112, 20)
        CamperStateLabel.TabIndex = 13
        CamperStateLabel.Text = "Camper State:"
        '
        'CamperBirthdayLabel
        '
        CamperBirthdayLabel.AutoSize = True
        CamperBirthdayLabel.Location = New System.Drawing.Point(165, 300)
        CamperBirthdayLabel.Name = "CamperBirthdayLabel"
        CamperBirthdayLabel.Size = New System.Drawing.Size(131, 20)
        CamperBirthdayLabel.TabIndex = 15
        CamperBirthdayLabel.Text = "Camper Birthday:"
        '
        'CamperFirstNameLabel
        '
        CamperFirstNameLabel.AutoSize = True
        CamperFirstNameLabel.Location = New System.Drawing.Point(279, 232)
        CamperFirstNameLabel.Name = "CamperFirstNameLabel"
        CamperFirstNameLabel.Size = New System.Drawing.Size(150, 20)
        CamperFirstNameLabel.TabIndex = 44
        CamperFirstNameLabel.Text = "Camper First Name:"
        '
        'CamperLastNameLabel
        '
        CamperLastNameLabel.AutoSize = True
        CamperLastNameLabel.Location = New System.Drawing.Point(279, 264)
        CamperLastNameLabel.Name = "CamperLastNameLabel"
        CamperLastNameLabel.Size = New System.Drawing.Size(150, 20)
        CamperLastNameLabel.TabIndex = 45
        CamperLastNameLabel.Text = "Camper Last Name:"
        '
        'HappyCampDataSet
        '
        Me.HappyCampDataSet.DataSetName = "HappyCampDataSet"
        Me.HappyCampDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'CamperBindingSource
        '
        Me.CamperBindingSource.DataMember = "Camper"
        Me.CamperBindingSource.DataSource = Me.HappyCampDataSet
        '
        'CamperTableAdapter
        '
        Me.CamperTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CamperTableAdapter = Me.CamperTableAdapter
        Me.TableAdapterManager.EnrollTableAdapter = Nothing
        Me.TableAdapterManager.ParentTableAdapter = Nothing
        Me.TableAdapterManager.RegistrationTableAdapter = Nothing
        Me.TableAdapterManager.SpecialtyTableAdapter = Nothing
        Me.TableAdapterManager.SummerStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CamperBindingNavigator
        '
        Me.CamperBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.CamperBindingNavigator.BindingSource = Me.CamperBindingSource
        Me.CamperBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.CamperBindingNavigator.DeleteItem = Nothing
        Me.CamperBindingNavigator.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.CamperBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.CamperBindingNavigatorSaveItem})
        Me.CamperBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.CamperBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.CamperBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.CamperBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.CamperBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.CamperBindingNavigator.Name = "CamperBindingNavigator"
        Me.CamperBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.CamperBindingNavigator.Size = New System.Drawing.Size(1311, 33)
        Me.CamperBindingNavigator.TabIndex = 0
        Me.CamperBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(54, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 31)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'CamperBindingNavigatorSaveItem
        '
        Me.CamperBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.CamperBindingNavigatorSaveItem.Image = CType(resources.GetObject("CamperBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.CamperBindingNavigatorSaveItem.Name = "CamperBindingNavigatorSaveItem"
        Me.CamperBindingNavigatorSaveItem.Size = New System.Drawing.Size(34, 28)
        Me.CamperBindingNavigatorSaveItem.Text = "Save Data"
        '
        'CamperAdressTextBox
        '
        Me.CamperAdressTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperAdress", True))
        Me.CamperAdressTextBox.Location = New System.Drawing.Point(809, 194)
        Me.CamperAdressTextBox.Name = "CamperAdressTextBox"
        Me.CamperAdressTextBox.Size = New System.Drawing.Size(200, 26)
        Me.CamperAdressTextBox.TabIndex = 8
        '
        'CamperZipCodeTextBox
        '
        Me.CamperZipCodeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperZipCode", True))
        Me.CamperZipCodeTextBox.Location = New System.Drawing.Point(809, 226)
        Me.CamperZipCodeTextBox.Name = "CamperZipCodeTextBox"
        Me.CamperZipCodeTextBox.Size = New System.Drawing.Size(200, 26)
        Me.CamperZipCodeTextBox.TabIndex = 10
        '
        'CamperCityTextBox
        '
        Me.CamperCityTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperCity", True))
        Me.CamperCityTextBox.Location = New System.Drawing.Point(809, 258)
        Me.CamperCityTextBox.Name = "CamperCityTextBox"
        Me.CamperCityTextBox.Size = New System.Drawing.Size(200, 26)
        Me.CamperCityTextBox.TabIndex = 12
        '
        'CamperBirthday
        '
        Me.CamperBirthday.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.CamperBindingSource, "CamperBirthday", True))
        Me.CamperBirthday.Location = New System.Drawing.Point(321, 300)
        Me.CamperBirthday.Name = "CamperBirthday"
        Me.CamperBirthday.Size = New System.Drawing.Size(298, 26)
        Me.CamperBirthday.TabIndex = 16
        '
        'Age8to10
        '
        Me.Age8to10.Location = New System.Drawing.Point(321, 361)
        Me.Age8to10.Name = "Age8to10"
        Me.Age8to10.Size = New System.Drawing.Size(108, 65)
        Me.Age8to10.TabIndex = 19
        Me.Age8to10.Text = "Ages 8 to 10"
        Me.Age8to10.UseVisualStyleBackColor = True
        '
        'Age12to15
        '
        Me.Age12to15.Location = New System.Drawing.Point(442, 361)
        Me.Age12to15.Name = "Age12to15"
        Me.Age12to15.Size = New System.Drawing.Size(108, 65)
        Me.Age12to15.TabIndex = 20
        Me.Age12to15.Text = "Age 12 to 15"
        Me.Age12to15.UseVisualStyleBackColor = True
        '
        'Age9to12
        '
        Me.Age9to12.Location = New System.Drawing.Point(574, 361)
        Me.Age9to12.Name = "Age9to12"
        Me.Age9to12.Size = New System.Drawing.Size(108, 65)
        Me.Age9to12.TabIndex = 21
        Me.Age9to12.Text = "Age 9 to 12"
        Me.Age9to12.UseVisualStyleBackColor = True
        '
        'BDayAll
        '
        Me.BDayAll.Location = New System.Drawing.Point(703, 361)
        Me.BDayAll.Name = "BDayAll"
        Me.BDayAll.Size = New System.Drawing.Size(108, 65)
        Me.BDayAll.TabIndex = 27
        Me.BDayAll.Text = "All Campers"
        Me.BDayAll.UseVisualStyleBackColor = True
        '
        'CamperStateTextBox
        '
        Me.CamperStateTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperState", True))
        Me.CamperStateTextBox.Location = New System.Drawing.Point(809, 295)
        Me.CamperStateTextBox.Name = "CamperStateTextBox"
        Me.CamperStateTextBox.Size = New System.Drawing.Size(200, 26)
        Me.CamperStateTextBox.TabIndex = 30
        '
        'CamperIDTextBox
        '
        Me.CamperIDTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperID", True))
        Me.CamperIDTextBox.Location = New System.Drawing.Point(442, 192)
        Me.CamperIDTextBox.Name = "CamperIDTextBox"
        Me.CamperIDTextBox.Size = New System.Drawing.Size(177, 26)
        Me.CamperIDTextBox.TabIndex = 31
        '
        'Bday
        '
        Me.Bday.Location = New System.Drawing.Point(840, 361)
        Me.Bday.Name = "Bday"
        Me.Bday.Size = New System.Drawing.Size(169, 65)
        Me.Bday.TabIndex = 34
        Me.Bday.Text = "Camper Age When Camp Starts"
        Me.Bday.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(510, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(239, 40)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Camper Form"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(972, 99)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(129, 31)
        Me.btnClose.TabIndex = 36
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Project_Part_2.My.Resources.Resources.Happy_Camp
        Me.PictureBox1.Location = New System.Drawing.Point(143, 91)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(166, 89)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 37
        Me.PictureBox1.TabStop = False
        '
        'btnFill
        '
        Me.btnFill.BackColor = System.Drawing.SystemColors.Window
        Me.btnFill.Location = New System.Drawing.Point(341, 103)
        Me.btnFill.Name = "btnFill"
        Me.btnFill.Size = New System.Drawing.Size(111, 31)
        Me.btnFill.TabIndex = 42
        Me.btnFill.Text = "Reset"
        Me.btnFill.UseVisualStyleBackColor = False
        '
        'CamperFirstNameComboBox
        '
        Me.CamperFirstNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperFirstName", True))
        Me.CamperFirstNameComboBox.DataSource = Me.CamperBindingSource
        Me.CamperFirstNameComboBox.DisplayMember = "CamperFirstName"
        Me.CamperFirstNameComboBox.FormattingEnabled = True
        Me.CamperFirstNameComboBox.Location = New System.Drawing.Point(442, 224)
        Me.CamperFirstNameComboBox.Name = "CamperFirstNameComboBox"
        Me.CamperFirstNameComboBox.Size = New System.Drawing.Size(177, 28)
        Me.CamperFirstNameComboBox.TabIndex = 45
        Me.CamperFirstNameComboBox.ValueMember = "CamperFirstName"
        '
        'CamperLastNameComboBox
        '
        Me.CamperLastNameComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.CamperBindingSource, "CamperLastName", True))
        Me.CamperLastNameComboBox.DataSource = Me.CamperBindingSource
        Me.CamperLastNameComboBox.DisplayMember = "CamperLastName"
        Me.CamperLastNameComboBox.FormattingEnabled = True
        Me.CamperLastNameComboBox.Location = New System.Drawing.Point(442, 256)
        Me.CamperLastNameComboBox.Name = "CamperLastNameComboBox"
        Me.CamperLastNameComboBox.Size = New System.Drawing.Size(177, 28)
        Me.CamperLastNameComboBox.TabIndex = 46
        Me.CamperLastNameComboBox.ValueMember = "CamperLastName"
        '
        'FillBy2ToolStrip
        '
        Me.FillBy2ToolStrip.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.FillBy2ToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CamperIDToolStripLabel, Me.CamperIDToolStripTextBox, Me.FillBy2ToolStripButton})
        Me.FillBy2ToolStrip.Location = New System.Drawing.Point(0, 33)
        Me.FillBy2ToolStrip.Name = "FillBy2ToolStrip"
        Me.FillBy2ToolStrip.Size = New System.Drawing.Size(1311, 34)
        Me.FillBy2ToolStrip.TabIndex = 47
        Me.FillBy2ToolStrip.Text = "FillBy2ToolStrip"
        '
        'CamperIDToolStripLabel
        '
        Me.CamperIDToolStripLabel.Name = "CamperIDToolStripLabel"
        Me.CamperIDToolStripLabel.Size = New System.Drawing.Size(96, 29)
        Me.CamperIDToolStripLabel.Text = "CamperID:"
        '
        'CamperIDToolStripTextBox
        '
        Me.CamperIDToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.CamperIDToolStripTextBox.Name = "CamperIDToolStripTextBox"
        Me.CamperIDToolStripTextBox.Size = New System.Drawing.Size(100, 34)
        '
        'FillBy2ToolStripButton
        '
        Me.FillBy2ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillBy2ToolStripButton.Name = "FillBy2ToolStripButton"
        Me.FillBy2ToolStripButton.Size = New System.Drawing.Size(68, 29)
        Me.FillBy2ToolStripButton.Text = "Search"
        '
        'CamperForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1311, 492)
        Me.Controls.Add(Me.FillBy2ToolStrip)
        Me.Controls.Add(CamperLastNameLabel)
        Me.Controls.Add(Me.CamperLastNameComboBox)
        Me.Controls.Add(CamperFirstNameLabel)
        Me.Controls.Add(Me.CamperFirstNameComboBox)
        Me.Controls.Add(Me.btnFill)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Bday)
        Me.Controls.Add(Me.CamperIDTextBox)
        Me.Controls.Add(Me.CamperStateTextBox)
        Me.Controls.Add(Me.BDayAll)
        Me.Controls.Add(Me.Age9to12)
        Me.Controls.Add(Me.Age12to15)
        Me.Controls.Add(Me.Age8to10)
        Me.Controls.Add(CamperIDLabel)
        Me.Controls.Add(CamperAdressLabel)
        Me.Controls.Add(Me.CamperAdressTextBox)
        Me.Controls.Add(CamperZipCodeLabel)
        Me.Controls.Add(Me.CamperZipCodeTextBox)
        Me.Controls.Add(CamperCityLabel)
        Me.Controls.Add(Me.CamperCityTextBox)
        Me.Controls.Add(CamperStateLabel)
        Me.Controls.Add(CamperBirthdayLabel)
        Me.Controls.Add(Me.CamperBirthday)
        Me.Controls.Add(Me.CamperBindingNavigator)
        Me.Name = "CamperForm"
        Me.Text = "CamperForm"
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CamperBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.CamperBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CamperBindingNavigator.ResumeLayout(False)
        Me.CamperBindingNavigator.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillBy2ToolStrip.ResumeLayout(False)
        Me.FillBy2ToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents HappyCampDataSet As HappyCampDataSet
    Friend WithEvents CamperBindingSource As BindingSource
    Friend WithEvents CamperTableAdapter As HappyCampDataSetTableAdapters.CamperTableAdapter
    Friend WithEvents TableAdapterManager As HappyCampDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CamperBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents CamperBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents CamperAdressTextBox As TextBox
    Friend WithEvents CamperZipCodeTextBox As TextBox
    Friend WithEvents CamperCityTextBox As TextBox
    Friend WithEvents CamperBirthday As DateTimePicker
    Friend WithEvents Age8to10 As Button
    Friend WithEvents Age12to15 As Button
    Friend WithEvents Age9to12 As Button
    Friend WithEvents BDayAll As Button
    Friend WithEvents CamperStateTextBox As TextBox
    Friend WithEvents CamperIDTextBox As TextBox
    Friend WithEvents Bday As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents btnClose As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnFill As Button
    Friend WithEvents CamperFirstNameComboBox As ComboBox
    Friend WithEvents CamperLastNameComboBox As ComboBox
    Friend WithEvents FillBy2ToolStrip As ToolStrip
    Friend WithEvents CamperIDToolStripLabel As ToolStripLabel
    Friend WithEvents CamperIDToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillBy2ToolStripButton As ToolStripButton
End Class
