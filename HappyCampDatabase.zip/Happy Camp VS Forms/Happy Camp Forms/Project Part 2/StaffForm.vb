﻿Public Class StaffForm
    Private Sub SummerStaffBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles SummerStaffBindingNavigatorSaveItem.Click
        Try
            Me.Validate()
            Me.SummerStaffBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.HappyCampDataSet)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub StaffForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'HappyCampDataSet.SummerStaff' table. You can move, or remove it, as needed.
        Me.SummerStaffTableAdapter.Fill(Me.HappyCampDataSet.SummerStaff)

    End Sub

    'This allows you to enter the last name
    Private Sub FillByToolStripButton_Click(sender As Object, e As EventArgs) Handles FillByToolStripButton.Click
        Try
            Me.SummerStaffTableAdapter.FillBy(Me.HappyCampDataSet.SummerStaff, LastNameToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
        If SummerStaffDataGridView.Rows(0).Cells("LastName").Value = "" Then
            MsgBox("No Staff Member Matched the Name")
        End If
    End Sub

    Dim IsAdding As Boolean = False
    Dim NewID As Integer
    Private Sub BindingNavigatorAddNewItem_Click(sender As Object, e As EventArgs) Handles BindingNavigatorAddNewItem.Click
        IsAdding = True
    End Sub
    Private Sub SummerStaffBindingSource_CurrentItemChanged(sender As Object, e As EventArgs) Handles SummerStaffBindingSource.CurrentItemChanged
        If (IsAdding) Then
            Try
                Dim cmd As New Data.SqlClient.SqlCommand
                cmd.CommandText = "SELECT Max(StaffID) AS MaxID FROM SummerStaff"
                cmd.CommandType = CommandType.Text
                cmd.Connection = Me.SummerStaffTableAdapter.Connection
                If cmd.Connection.State = ConnectionState.Closed Then
                    cmd.Connection.Open()
                    NewID = cmd.ExecuteScalar() + 1
                    cmd.Connection.Close()
                End If
                SummerStaffDataGridView.Rows(SummerStaffDataGridView.Rows.Count - 2).Cells("StaffID").Value = NewID
                IsAdding = False
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
        End If

    End Sub

    'This solves closing problems
    Private Sub StaffForm_Closing(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        SummerStaffBindingSource.Dispose()
        SummerStaffDataGridView.Dispose()
    End Sub

    'This closes the form
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub Fill_Click(sender As Object, e As EventArgs) Handles Fill.Click
        Try
            Me.SummerStaffTableAdapter.Fill(Me.HappyCampDataSet.SummerStaff)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class