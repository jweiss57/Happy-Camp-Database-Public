﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class StaffForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(StaffForm))
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.SummerStaffBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.SummerStaffBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.HappyCampDataSet = New Project_Part_2.HappyCampDataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.SummerStaffBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.SummerStaffDataGridView = New System.Windows.Forms.DataGridView()
        Me.StaffID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StaffFirstName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LastName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FillByToolStrip = New System.Windows.Forms.ToolStrip()
        Me.LastNameToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me.LastNameToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.FillByToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.SummerStaffTableAdapter = New Project_Part_2.HappyCampDataSetTableAdapters.SummerStaffTableAdapter()
        Me.TableAdapterManager = New Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Fill = New System.Windows.Forms.Button()
        CType(Me.SummerStaffBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SummerStaffBindingNavigator.SuspendLayout()
        CType(Me.SummerStaffBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SummerStaffDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FillByToolStrip.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SummerStaffBindingNavigator
        '
        Me.SummerStaffBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.SummerStaffBindingNavigator.BindingSource = Me.SummerStaffBindingSource
        Me.SummerStaffBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.SummerStaffBindingNavigator.DeleteItem = Nothing
        Me.SummerStaffBindingNavigator.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.SummerStaffBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.SummerStaffBindingNavigatorSaveItem})
        Me.SummerStaffBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.SummerStaffBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.SummerStaffBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.SummerStaffBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.SummerStaffBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.SummerStaffBindingNavigator.Name = "SummerStaffBindingNavigator"
        Me.SummerStaffBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.SummerStaffBindingNavigator.Size = New System.Drawing.Size(1006, 38)
        Me.SummerStaffBindingNavigator.TabIndex = 0
        Me.SummerStaffBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(34, 33)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'SummerStaffBindingSource
        '
        Me.SummerStaffBindingSource.DataMember = "SummerStaff"
        Me.SummerStaffBindingSource.DataSource = Me.HappyCampDataSet
        '
        'HappyCampDataSet
        '
        Me.HappyCampDataSet.DataSetName = "HappyCampDataSet"
        Me.HappyCampDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(54, 28)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 31)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 33)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(34, 28)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 33)
        '
        'SummerStaffBindingNavigatorSaveItem
        '
        Me.SummerStaffBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.SummerStaffBindingNavigatorSaveItem.Image = CType(resources.GetObject("SummerStaffBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.SummerStaffBindingNavigatorSaveItem.Name = "SummerStaffBindingNavigatorSaveItem"
        Me.SummerStaffBindingNavigatorSaveItem.Size = New System.Drawing.Size(34, 28)
        Me.SummerStaffBindingNavigatorSaveItem.Text = "Save Data"
        '
        'SummerStaffDataGridView
        '
        Me.SummerStaffDataGridView.AutoGenerateColumns = False
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SummerStaffDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.SummerStaffDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.SummerStaffDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StaffID, Me.StaffFirstName, Me.LastName, Me.DataGridViewTextBoxColumn4})
        Me.SummerStaffDataGridView.DataSource = Me.SummerStaffBindingSource
        Me.SummerStaffDataGridView.Location = New System.Drawing.Point(39, 220)
        Me.SummerStaffDataGridView.Name = "SummerStaffDataGridView"
        Me.SummerStaffDataGridView.RowHeadersWidth = 62
        Me.SummerStaffDataGridView.RowTemplate.Height = 28
        Me.SummerStaffDataGridView.Size = New System.Drawing.Size(923, 220)
        Me.SummerStaffDataGridView.TabIndex = 1
        '
        'StaffID
        '
        Me.StaffID.DataPropertyName = "StaffID"
        Me.StaffID.HeaderText = "Staff ID"
        Me.StaffID.MinimumWidth = 8
        Me.StaffID.Name = "StaffID"
        Me.StaffID.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.StaffID.Width = 70
        '
        'StaffFirstName
        '
        Me.StaffFirstName.DataPropertyName = "StaffFirstName"
        Me.StaffFirstName.HeaderText = "First Name"
        Me.StaffFirstName.MinimumWidth = 8
        Me.StaffFirstName.Name = "StaffFirstName"
        Me.StaffFirstName.Width = 150
        '
        'LastName
        '
        Me.LastName.DataPropertyName = "StaffLastName"
        Me.LastName.HeaderText = "Last Name"
        Me.LastName.MinimumWidth = 8
        Me.LastName.Name = "LastName"
        Me.LastName.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.LastName.Width = 150
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "StaffContactNumber"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Contact Number"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 8
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 150
        '
        'FillByToolStrip
        '
        Me.FillByToolStrip.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.FillByToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LastNameToolStripLabel, Me.LastNameToolStripTextBox, Me.FillByToolStripButton})
        Me.FillByToolStrip.Location = New System.Drawing.Point(0, 38)
        Me.FillByToolStrip.Name = "FillByToolStrip"
        Me.FillByToolStrip.Size = New System.Drawing.Size(1006, 38)
        Me.FillByToolStrip.TabIndex = 2
        Me.FillByToolStrip.Text = "FillByToolStrip"
        '
        'LastNameToolStripLabel
        '
        Me.LastNameToolStripLabel.Name = "LastNameToolStripLabel"
        Me.LastNameToolStripLabel.Size = New System.Drawing.Size(94, 29)
        Me.LastNameToolStripLabel.Text = "LastName:"
        '
        'LastNameToolStripTextBox
        '
        Me.LastNameToolStripTextBox.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.LastNameToolStripTextBox.Name = "LastNameToolStripTextBox"
        Me.LastNameToolStripTextBox.Size = New System.Drawing.Size(100, 34)
        '
        'FillByToolStripButton
        '
        Me.FillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.FillByToolStripButton.Name = "FillByToolStripButton"
        Me.FillByToolStripButton.Size = New System.Drawing.Size(68, 29)
        Me.FillByToolStripButton.Text = "Search"
        '
        'SummerStaffTableAdapter
        '
        Me.SummerStaffTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CamperTableAdapter = Nothing
        Me.TableAdapterManager.EnrollTableAdapter = Nothing
        Me.TableAdapterManager.ParentTableAdapter = Nothing
        Me.TableAdapterManager.RegistrationTableAdapter = Nothing
        Me.TableAdapterManager.SpecialtyTableAdapter = Nothing
        Me.TableAdapterManager.SummerStaffTableAdapter = Me.SummerStaffTableAdapter
        Me.TableAdapterManager.UnitStaffTableAdapter = Nothing
        Me.TableAdapterManager.UnitTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Project_Part_2.HappyCampDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Project_Part_2.My.Resources.Resources.Happy_Camp
        Me.PictureBox1.Location = New System.Drawing.Point(15, 110)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(166, 89)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 40
        Me.PictureBox1.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(844, 118)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(129, 31)
        Me.btnClose.TabIndex = 39
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(382, 110)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(185, 40)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Staff Form"
        '
        'Fill
        '
        Me.Fill.Location = New System.Drawing.Point(241, 108)
        Me.Fill.Name = "Fill"
        Me.Fill.Size = New System.Drawing.Size(99, 41)
        Me.Fill.TabIndex = 41
        Me.Fill.Text = "Reset"
        Me.Fill.UseVisualStyleBackColor = True
        '
        'StaffForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Window
        Me.ClientSize = New System.Drawing.Size(1006, 540)
        Me.Controls.Add(Me.Fill)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.FillByToolStrip)
        Me.Controls.Add(Me.SummerStaffDataGridView)
        Me.Controls.Add(Me.SummerStaffBindingNavigator)
        Me.Name = "StaffForm"
        Me.Text = "StaffForm"
        CType(Me.SummerStaffBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SummerStaffBindingNavigator.ResumeLayout(False)
        Me.SummerStaffBindingNavigator.PerformLayout()
        CType(Me.SummerStaffBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.HappyCampDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SummerStaffDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FillByToolStrip.ResumeLayout(False)
        Me.FillByToolStrip.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents HappyCampDataSet As HappyCampDataSet
    Friend WithEvents SummerStaffBindingSource As BindingSource
    Friend WithEvents SummerStaffTableAdapter As HappyCampDataSetTableAdapters.SummerStaffTableAdapter
    Friend WithEvents TableAdapterManager As HappyCampDataSetTableAdapters.TableAdapterManager
    Friend WithEvents SummerStaffBindingNavigator As BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As ToolStripLabel
    Friend WithEvents BindingNavigatorMoveFirstItem As ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As ToolStripSeparator
    Friend WithEvents SummerStaffBindingNavigatorSaveItem As ToolStripButton
    Friend WithEvents SummerStaffDataGridView As DataGridView
    Friend WithEvents FillByToolStrip As ToolStrip
    Friend WithEvents LastNameToolStripLabel As ToolStripLabel
    Friend WithEvents LastNameToolStripTextBox As ToolStripTextBox
    Friend WithEvents FillByToolStripButton As ToolStripButton
    Friend WithEvents StaffID As DataGridViewTextBoxColumn
    Friend WithEvents StaffFirstName As DataGridViewTextBoxColumn
    Friend WithEvents LastName As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnClose As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Fill As Button
End Class
